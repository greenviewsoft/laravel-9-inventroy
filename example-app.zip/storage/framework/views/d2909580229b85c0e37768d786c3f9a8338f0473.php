<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                 Easy Shop © 2022
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Crafted with <i class="mdi mdi-heart text-danger"></i> by  Easy Shop
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH F:\xampp\htdocs\laravel admin panel with login regiser\example-app\resources\views/admin/body/footer.blade.php ENDPATH**/ ?>