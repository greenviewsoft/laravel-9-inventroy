<!DOCTYPE html>
<html>
<head>
    <title>Green View Soft</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>


<div> 

    <img src="<?php echo e(public_path('backend/assets/images/greenit.png')); ?>" style="width: 120px; height: 70px">
    <h1>GreenViewSoft</h1>
    <h3>Purchase Report</h3>
    <p> Date:<?php echo e(date('d-m-Y')); ?> </p> 
   
    
    
    <p><strong>Note:</strong>This Invoice Only Test Purpose</p>
<div class="table-responsive">
    <table class="table">
        <thead>
        <tr>
            <td><strong>Sl </strong></td>
            <td class="text-center"><strong>Purchase No  </strong>
            </td>
            <td class="text-center"><strong>Date</strong>
            </td>
            <td class="text-center"><strong>Product Name </strong></td>
            <td class="text-center"><strong>Quanity</strong>
            </td>
            <td class="text-center"><strong>Unit Price   </strong>
            </td>
            <td class="text-center"><strong>Total Price  </strong>
            </td>


        </tr>
        </thead>
        <tbody>
       
            <?php
            $total_sum = '0';
            ?>
      
        <?php $__currentLoopData = $calldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      
        <tr>
            <td class="text-center"><?php echo e($key+1); ?></td>
            <td class="text-center"><?php echo e($item->purchase_no); ?></td>
            <td class="text-center"><?php echo e(date('d-m-Y',strtotime($item->date))); ?></td>
            <td class="text-center"><?php echo e($item['product']['name']); ?></td>
            <td class="text-center"><?php echo e($item->buying_qty); ?> <?php echo e($item['product']['unit']['name']); ?></td>
            <td class="text-center"><?php echo e($item->unit_price); ?></td>
            <td class="text-center"><?php echo e($item->buying_price); ?></td>



        </tr>
        <?php
        $total_sum += $item->buying_price;
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tr>
                <td class="no-line"></td>
                <td class="no-line"></td>
                <td class="no-line"></td> 
                <td class="no-line"></td>
                <td class="no-line text-center">
                    <strong>Grand Total</strong></td>
                <td class="no-line text-end"><h4 class="m-0"> <?php echo e($total_sum); ?></h4></td>
            </tr>

                            </tbody>
                        </table>
                    </div>

                    <?php
                    $date = new DateTime('now', new DateTimeZone('Asia/Dhaka')); 
                    ?>         
                    <i>Printing Time : <?php echo e($date->format('F j, Y, g:i a')); ?></i>   
                               <br>       <br>   <br>
                    <p><strong>Signature</strong></p>
 
                    <p class="text-center"><strong>End Of Repoort</strong></p>
                    
 </body>
 </html><?php /**PATH F:\xampp\htdocs\admin panel laravel\example-app\resources\views/backend/downloadpdf/dailypurchase.blade.php ENDPATH**/ ?>