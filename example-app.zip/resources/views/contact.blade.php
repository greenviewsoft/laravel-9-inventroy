<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact</title>
</head>
<body>
    <h1>Contact Page from contoller </h1>
    <a href="{{ url('/about') }}" > Abouts  </a>
</body>
</html>